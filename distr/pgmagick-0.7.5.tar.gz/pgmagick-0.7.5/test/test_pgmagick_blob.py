import sys
sys.path.append('../')
sys.path.append('./')
from pgmagick import Blob
