// This may look like C code, but it is really -*- C++ -*-
//
// Copyright Bob Friesenhahn, 1999, 2000, 2001, 2002
//
// Definition of an Image reference
//
// This is a private implementation class which should never be
// referenced by any user code.
//

#if !defined(Magick_ImageRef_header)
#define Magick_ImageRef_header

#include "Magick++/Include.h"
#include "Magick++/Thread.h"

namespace Magick
{
  class Options;

  //
  // Reference counted access to Image *
  //
  class MagickDLLDecl ImageRef {
    friend class Image;
  private:
    // Construct with an image pointer and default options
    ImageRef ( MagickLib::Image * image_ );
    // Construct with an image pointer and options
    ImageRef ( MagickLib::Image * image_, const Options * options_ );
    // Construct with null image and default options
    ImageRef ( void );
    // Destroy image and options
    ~ImageRef ( void );

    // Copy constructor and assignment are not supported
    ImageRef(const ImageRef&);
    ImageRef& operator=(const ImageRef&);

    void                 image ( MagickLib::Image * image_ );
    MagickLib::Image *&  image ( void );

    void                 options ( Options * options_ );
    Options *            options ( void );

    void                 id ( const long id_ );
    long                 id ( void ) const;

    MagickLib::Image *   _image;    // ImageMagick Image
    Options *            _options;  // User-specified options
    long                 _id;       // Registry ID (-1 if not registered)
    int                  _refCount; // Reference count
    MutexLock            _mutexLock;// Mutex lock
  };

} // end of namespace Magick

//
// Inlines
//

// Retrieve image from reference
inline MagickLib::Image *& Magick::ImageRef::image ( void )
{
  return _image;
}

// Retrieve Options from reference
inline Magick::Options * Magick::ImageRef::options ( void )
{
  return _options;
}

// Retrieve registration id from reference
inline long Magick::ImageRef::id ( void ) const
{
  return _id;
}

#endif // Magick_ImageRef_header
